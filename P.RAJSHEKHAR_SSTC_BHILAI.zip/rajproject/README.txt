This  Website was given as a task during placement at SHRI SHANKARACHARYA TECHNICAL CAMPUS ,junwani Bhilai.
Due to power cut my code was lost that day so after completing all the previous rounds but due to power cut code for my last round was lost
so I was told to produce the full-stack website given that day with working registration page using PHP
I have this complete working website with working registration page as I wasn't told to do the authentication part so haven't done the same
registration works and the data is automatically saved to the database.
