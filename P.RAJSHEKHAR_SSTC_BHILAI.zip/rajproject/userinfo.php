<?php

$con = mysqli_connect('localhost','root');

// if($con){
// 	//echo "Connection successful";
// }else{
// 	echo "No connection please refresh";
// }

mysqli_select_db($con, 'rajproject');
 $fullname = $_POST['fullname'];
 $username = $_POST['username'];
 $email = $_POST['email'];
 $phone = $_POST['phone'];
 $password = $_POST['password'];
 $confirmpassword = $_POST['confirmpassword'];

 $query = " insert into userinfodata (fullname,username,email,phone,password,confirmpassword)
 values ('$fullname', '$username', '$email', '$phone', '$password', '$confirmpassword') ";

// echo "$query";
 
mysqli_query($con, $query); 
header("Location:index.php");

 ?>