<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>projectmanagement</title>

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat|Ubuntu" rel="stylesheet">

  <!-- CSS Stylesheets -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="css/styles.css">
   
  <!-- Font Awesome -->
  <script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>

  <!-- Bootstrap Scripts -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>

<body>

  <section class="colored-section" id="title">

    <!-- Nav Bar -->

      <nav class="navbar navbar-expand-lg navbar-dark">

        <a class="navbar-brand" href=""><i class="fa fa-cube" aria-hidden="true"></i> projectmanagement</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">

          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#footer">Project</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#pricing">description</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#cta">prototype</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#cta">-------------------</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="login.php">Login</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="registration.php">Register</a>
            </li>
          </ul>

        </div>
      </nav>

    <div class="container-fluid">      


      <!-- Title -->

      <div class="row">

        <div class="col-lg-6">
          <h1 class="big-heading">Business Platform For Project Management Portal</h1>
          <p>Let Blackcombine take care of the attendance, payroll, bookkeeping, and taxation processess so you can focus more on business development</p>
          <button type="button" class="btn btn-dark btn-lg start-button">Get Started</button>
          <button type="button" class="btn btn-outline-light btn-lg start-button"><i class="fa fa-globe" aria-hidden="true"></i> Learn More</button>

          <hr class="popular-hr">
          <h5 class="popular">Popular</h5>
          <div class="popular-item">
            <ul>
              <li class="pop-item">
                <a><i class="fa fa-link" aria-hidden="true"></i> Payroll & HRIS</a>
              </li>
              <li class="pop-item">
                <a><i class="fa fa-calendar-plus-o" aria-hidden="true"></i> Accountancy</a>
              </li>
              <li class="pop-item">
                <a><i class="fa fa-money" aria-hidden="true"></i> Taxation</a>
              </li>
              <li class="pop-item">
                <a><i class="fa fa-recycle" aria-hidden="true"></i> CRM</a>
              </li>
            </ul>
          </div>

        </div>

        <div class="col-lg-6">
          <div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/network.png" alt="networks" width="500" height="500">
      
    </div>
    <div class="carousel-item">
       <img src="images/network.png" alt="networks" width="500" height="500">
         
    </div>

          
        </div>

      </div>

    </div>

  </section>

  <section id="brands">
    <img class="brands-logo" src="images/ClickUp-Logo.png" alt="tc-logo">
    <img class="brands-logo" src="images/Dropbox-Logo.png" alt="tnw-logo">
    <img class="brands-logo" src="images/Twilio-Segment.png" alt="biz-insider-logo">
    <img class="brands-logo" src="images/ServiceNow_logo.png" alt="mashable-logo">
  </section>
  <section class="my-5">
    <div class="py-2">
      <h1 class="text-centre display-4">Continue To Grow</h1>
      <h1 class="text-centre display-4">With Businesses In The Word</h1>
      <p>Blackcombine is here to make it easier for all businesses and companies </p>
      <p>in indonesia to be able to continue to grow</p>
    </div>
    <div>
      <img src="images/tax.png" alt="networks" width="200" height="200">
      <img src="images/web.png" alt="networks" width="800" height="200">
      <img src="images/Pay.png" alt="networks" width="300" height="300">
    </div>  
  </section>
  <section class="my-5">
    <div class="py-2">
      <h1 class="text-centre display-4">The Answer To Your Business Need</h1>
      <p>Make HR administration processes more efficient and avoid mistakes in the payroll</p>
      <p>process through automation</p>
      <div class="center-align">
            
              <li>
                <a><i class="fa fa-link" aria-hidden="true"></i> Payroll & HRIS</a>
              
              
                <a><i class="fa fa-calendar-plus-o" aria-hidden="true"></i> Accountancy</a>
              
              
                <a><i class="fa fa-money" aria-hidden="true"></i> Taxation</a>
              
              
                <a><i class="fa fa-recycle" aria-hidden="true"></i> CRM</a>
              </li>

          </div>
      
    </div>
  </section>
  <section>
     
          <div>
             <img src="images/graph.png" alt="networks" width="1100" height="450">
          </div>
     
  </section>
  <section class="my-5">
  <div class="container center-align">      
          <h1 class="big-heading text-white">Ready To Move Forward With </h1>
          <h1 class="text-white">Blackcombine?</h1>
          <p>Let Blackcombine take care of the attendance, payroll, bookkeeping, and taxation processess so you can focus more on business development</p>
          <button type="button" href="./registration.php" class="btn btn-dark btn-lg start-button center-align">Get Started</button>
  </div>
  </section>
  <footer>
    
  <p>copyright &#169 2020-2021 first boulevard.all rights reserved.</p>
  <p>By using this websites.you understand the information being prevented is proivded for informational purpose only and agree to our terms of use and privacy policy</p>
  
</footer>
  
  

</body>
<script src="script.js"></script>
</html>
